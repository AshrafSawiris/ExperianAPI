﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace experian_album_api.Serializers
{
    public class CustomJsonSerializer : ISerializer
    {
        readonly ILogger<CustomJsonSerializer> _logger;
        private string _localLoggerPrefix;
        public CustomJsonSerializer(ILogger<CustomJsonSerializer> logger)
        {
            _logger = logger;
        }

        public async Task<T> DeserializeJsonAsync<T>(string jsonData, JsonSerializerOptions options = null)
        {

            var defaultOptions = new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true
            };

            var serializerOptions = options != null ? options : defaultOptions;

            try
            {
                return JsonSerializer.Deserialize<T>(jsonData, serializerOptions);
            }

            catch (ArgumentNullException ex)
            {
                _logger.LogError(ex, $"{_localLoggerPrefix}.exception");

                throw ex;
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, $"{_localLoggerPrefix}.exception");
                throw ex;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{_localLoggerPrefix}.exception");
                throw ex;
            }
        }
    }
}
