﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace experian_album_api.Serializers
{
    public interface ISerializer
    {
        Task<T> DeserializeJsonAsync<T>(string jsonData, JsonSerializerOptions options = null);
    }
}
