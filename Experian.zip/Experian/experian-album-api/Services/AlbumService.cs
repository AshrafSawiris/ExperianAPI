﻿using experian_album_api.Models;
using experian_album_api.Serializers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using System.Net.Http;

namespace experian_album_api.Services
{
    public class AlbumService : IAlbumService
    {
        const string _albums = "albums";
        const string _photos = "photos";
        private const string _loggingPrefix = nameof(AlbumService);
        readonly HttpClient _httpClient;
        readonly ILogger<AlbumService> _logger;
        private readonly ISerializer _serializer;
        private string _localLoggerPrefix;
       
        public AlbumService(HttpClient httpClient, ILogger<AlbumService> logger,  ISerializer serializer)
        {
            _httpClient = httpClient;
            _logger = logger;
            _serializer = serializer;
        }

        public async Task<IEnumerable<Album>> GetAlbumsAsync()
        {
            _localLoggerPrefix = _loggingPrefix + "." + nameof(GetAlbumsAsync);
            _logger.LogInformation($"{_localLoggerPrefix}.start ");

            try
            {
                return await GetAlbumsAsync(_albums);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{_localLoggerPrefix}.exception");
                throw;
            }
            finally
            {
                _logger.LogInformation($"{_localLoggerPrefix}.completed");
            }
        }
        private async Task<IEnumerable<Album>> GetAlbumsAsync(string path)
        {
            var albumsJsonData = await GetResponseAsync(path);
            var albums = await _serializer.DeserializeJsonAsync<IEnumerable<Album>>(albumsJsonData);

            if (albums == null || !albums.Any()) return albums;

            await Task.WhenAll(albums.Select(GetPhotosByAlbumIdAsync));
            return albums;
        }

        private async Task GetPhotosByAlbumIdAsync(Album album)
        {
            album.Photos = await GetPhotosByAlbumIdAsync(album.Id);
        }

        private async Task<IEnumerable<Photo>> GetPhotosByAlbumIdAsync(int albumId)
        {
            _localLoggerPrefix = _loggingPrefix + "." + nameof(GetPhotosByAlbumIdAsync);
            _logger.LogInformation($"{_localLoggerPrefix}.start ");

            try
            {
                var photosJsonData = await GetResponseAsync($"album/{albumId}/photos");
                var photos = await _serializer.DeserializeJsonAsync<IEnumerable<Photo>>(photosJsonData);
                return photos;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{_localLoggerPrefix}.exception");

                throw;
            }
            finally
            {
                _logger.LogInformation($"{_localLoggerPrefix}.completed");
            }
        }

        private async Task<string> GetResponseAsync(string resoursePath)
        {
            _localLoggerPrefix = _loggingPrefix + "." + nameof(GetResponseAsync);

            _logger.LogInformation($"{_localLoggerPrefix}.start ");

            if (string.IsNullOrWhiteSpace(resoursePath)) throw new ArgumentNullException(nameof(resoursePath));

            try
            {
                _logger.LogInformation("Requesting data from url {BaseAddress}{Url}", _httpClient.BaseAddress, resoursePath);
                
                var response = await _httpClient.GetAsync(resoursePath);
               
                response.EnsureSuccessStatusCode();

                return await response.Content.ReadAsStringAsync();

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{_localLoggerPrefix}.exception");
                throw;
            }
        }

        public async Task<Album> GetAlbumAsync(int albumId)
        {
            _localLoggerPrefix = _loggingPrefix + "." + nameof(GetAlbumAsync);
            _logger.LogInformation($"{_localLoggerPrefix}.start ");

            try
            {
                var albumResponse = await GetResponseAsync($"albums/{albumId}");

                var album = await _serializer.DeserializeJsonAsync<Album>(albumResponse);

                if (album == null) return album;

                album.Photos = await GetPhotosByAlbumIdAsync(albumId);

                return album;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{_localLoggerPrefix}.exception");

                throw;
            }
            finally
            {
                _logger.LogInformation($"{_localLoggerPrefix}.completed");
            }
        }
    }
}
