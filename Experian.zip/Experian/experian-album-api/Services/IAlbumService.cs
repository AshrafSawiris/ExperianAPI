﻿using experian_album_api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace experian_album_api.Services
{
    public interface IAlbumService
    {
        Task<IEnumerable<Album>> GetAlbumsAsync();

        Task<Album> GetAlbumAsync(int albumId);

    }
}
