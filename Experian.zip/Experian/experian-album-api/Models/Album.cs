﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace experian_album_api.Models
{
    public class Album : BaseEntity
    {
        public int UserId { get; set; }
        public string Title { get; set; }
        public IEnumerable<Photo> Photos { get; set; }

        public static explicit operator OkObjectResult(Album v)
        {
            throw new NotImplementedException();
        }
    }
}
