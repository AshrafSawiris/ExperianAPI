﻿using System;

namespace experian_album_api.Models
{
    public abstract class BaseEntity
    {
      public int Id { get; set; }
    }
}
