﻿using experian_album_api.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Net.Mime;


namespace experian_album_api.Extensions
{
    public static class ServiceCollection
    {
        public static IServiceCollection AddCustomMvc(this IServiceCollection services)
        {
            services.AddControllers();

            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                    .SetIsOriginAllowed((host) => true)
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });

            return services;
        }

        public static IServiceCollection AddHttpClients(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddHttpClient<IAlbumService, AlbumService>(client =>
            {
                client.BaseAddress = new Uri(configuration["AlbumService:BaseUrl"]);
                client.DefaultRequestHeaders.Add("Accept", MediaTypeNames.Application.Json);
            })

            .SetHandlerLifetime(TimeSpan.FromMinutes(5));
            return services;
        }
    }
}
