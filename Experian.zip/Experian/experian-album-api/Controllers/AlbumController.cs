﻿using experian_album_api.Models;
using experian_album_api.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace experian_album_api.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AlbumController : ControllerBase
    {
        private readonly IAlbumService _albumService;
        private readonly ILogger<AlbumController> _logger;

        public AlbumController(
            ILogger<AlbumController> logger, 
            IAlbumService albumService)
        {
            _logger = logger;
            _albumService = albumService;
        }
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IEnumerable<Album>> GetAllAsync()
        {
            var response = await _albumService.GetAlbumsAsync();
            return response;
        }

        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<Album> GetAlbums(int albumId)
        {
            var response = await _albumService.GetAlbumAsync(albumId);
            return response;
        }
    }
}
