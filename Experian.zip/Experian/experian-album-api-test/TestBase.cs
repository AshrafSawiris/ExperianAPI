﻿using AutoMapper;

namespace experian_album_api_test
{
    public abstract class TestBase
    {
        static TestBase()
        {
            Mapper.Initialize(_ => _.AddProfile<AutoMapperProfile>());
        }
    }
}
