using experian_album_api.Controllers;
using experian_album_api.Models;
using experian_album_api.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;

namespace experian_album_api_test
{
    [TestClass]
    public class AlbumsControllerTests
    {
        protected readonly AlbumController _albumController;
        protected readonly Mock<IAlbumService> _albumServiceMock = new Mock<IAlbumService>();
        protected readonly Mock<ILogger<AlbumController>> _loggerMock;

        protected AlbumsControllerTests()
        {
            _albumServiceMock = new Mock<IAlbumService>();

            _loggerMock = new Mock<ILogger<AlbumController>>();

            _albumController = new AlbumController((ILogger<AlbumController>)_albumServiceMock.Object, (IAlbumService)_loggerMock.Object);
        }

        [TestMethod]
        public async Task GetAllAsync_HasNoAlbums()
        {
            var albums = new List<Album>();

            _albumServiceMock.Setup(x => x.GetAlbumsAsync())
                .ReturnsAsync(albums);

            var response = await _albumController.GetAllAsync();

            Assert.IsNotNull(response);
            Assert.IsInstanceOfType(response, typeof(IEnumerable<Album>));
            Assert.IsFalse(response.Any());
        }


        [TestMethod]
        public async Task GetAlbumsAsync_ByAlbumId_NotFound()
        {
            _albumServiceMock.Setup(x => x.GetAlbumsAsync())
               .ReturnsAsync(null as IEnumerable<Album>);

            var actionResult = await _albumController.GetAlbums(55500);
            var okResult = (OkObjectResult)actionResult;
            Assert.IsNull(actionResult);
            Assert.AreEqual(StatusCodes.Status404NotFound, okResult.StatusCode);
        }

        [TestMethod]
        public async Task GetAlbumsAsync_OKWithAlbumsList()
        {
            var albums = new List<Album>
            {
                new Album {Id = 1, Title = "Album A",  UserId = 1},
                new Album {Id = 2, Title = "Album B", UserId = 1},
                new Album {Id = 2, Title = "Album C", UserId = 1},
            };

            _albumServiceMock.Setup(x => x.GetAlbumsAsync())
              .ReturnsAsync(albums);

            var actionResult = await _albumController.GetAllAsync();
            var okResult = (OkObjectResult)actionResult;
            var responseAlbums = okResult.Value as IEnumerable<Album>;

            Assert.IsNotNull(okResult);
            Assert.IsNotNull(responseAlbums);
            Assert.AreEqual(StatusCodes.Status200OK, okResult.StatusCode);
            Assert.AreNotEqual(2, responseAlbums.Count());
        }

        [TestMethod]
        public async Task GetAlbumsPhotosAsync_AlbumExist_OKWithAlbumsList()
        {
            var album = new List<Album>();
            var photos = new List<Photo>
            {
                new Photo {AlbumId = 1, Title = "Album One", Url="/picture1" ,ThumbnailUrl="thumbnailUrl1"},
                new Photo {AlbumId = 1, Title = "Album One", Url="/picture2", ThumbnailUrl="ThumbnailUrl2"}
            };

             _albumServiceMock.Setup(x => x.GetAlbumsAsync())
              .ReturnsAsync(album);

            var actionResult = await _albumController.GetAllAsync();

            var okResult = (OkObjectResult)actionResult;
            var responseAlbums = okResult.Value as IEnumerable<Photo>;

            Assert.IsNotNull(okResult);
            Assert.IsNotNull(responseAlbums);
            Assert.AreEqual(StatusCodes.Status200OK, okResult.StatusCode);
            Assert.AreEqual(2, responseAlbums.Count());
        }
    }
}